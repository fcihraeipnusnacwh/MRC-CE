# -*- coding: utf-8 -*-
"""
Created on Mon Jan 11 09:08:21 2021

@author: yuansiyu
"""


dataset1 = []
with open('MRC-CE_result10.txt', 'r', encoding="utf-8") as f1:
    for data in f1.readlines():
        if data == '\n':
            continue
        info, raw, cons = data.replace('\n','').split('\t')
        cons = cons.split(',')
        con_dic = {}
        for ele in cons:
            if len(ele) == 0:
                continue
            else:
                con_dic[ele[:-1]] = ele[-1]
        dataset1.append([info, raw, con_dic])
f1.close()

dataset2 = []
with open('Bert_mrc_rule_result10.txt', 'r', encoding="utf-8") as f1:
    for data in f1.readlines():
        if data == '\n':
            continue
        info, raw, cons = data.replace('\n','').split('\t')
        cons = cons.split(',')
        con_dic = {}
        for ele in cons:
            if len(ele) == 0:
                continue
            else:
                con_dic[ele[:-1]] = ele[-1]
        dataset2.append([info, raw, con_dic])
f1.close()

l1 = len(dataset1)
l2 = len(dataset2)
k = 0
for i in range(l2):
    info, raw, con_dic = dataset1[i]
    for con in con_dic.keys():
        if con_dic[con] == '1':
            dataset2[i][2][con] = '1'
            print(con)
            k = k+1
        if con_dic[con] == '2':
            dataset2[i][2][con] = '2'
            print(con)
            k = k+1

with open('Bert_mrc_rule_result_easysee10.txt', 'w', encoding="utf-8") as f1:
    for data in dataset2:
        f1.write(data[0])
        f1.write('-----')
        f1.write(data[1])
        f1.write('-----')
        con_dic = data[2]
        con_ls = []
        for key in con_dic.keys():
            con_ls.append(key+con_dic[key])
        f1.write(','.join(con_ls))
        f1.write('\n')
f1.close()